package com.project.NBFC.Model;

import java.util.ArrayList;

public class ResponseChartData {
		ArrayList<String> labels;
		
		ArrayList<Double> values;

		public ArrayList<String> getLabels() {
			return labels;
		}

		public void setLabels(ArrayList<String> labels) {
			this.labels = labels;
		}

		public ArrayList<Double> getValues() {
			return values;
		}

		public void setValues(ArrayList<Double> values) {
			this.values = values;
		}

		
}
