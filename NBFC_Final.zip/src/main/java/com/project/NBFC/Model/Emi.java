package com.project.NBFC.Model;

public class Emi {

	private int account_no;

	public int getAccount_no() {
		return account_no;
	}

	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
}
