package com.project.NBFC.Model;

public class chartTypeSearch {
		String type;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

}
