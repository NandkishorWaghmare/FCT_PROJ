package com.project.NBFC.Services;

import com.project.NBFC.Model.Guarantors;

public interface GuarantorService {

	public Guarantors saveGuarantor(Guarantors g);
}
