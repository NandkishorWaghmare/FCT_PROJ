package com.project.NBFC.Services;

import com.project.NBFC.Model.NBFC;

public interface NBFCService 
{
	public void saveNBFCinfo(NBFC obj);
	public NBFC getbyid(int id);
	
}
