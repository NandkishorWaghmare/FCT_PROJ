package com.project.NBFC.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.NBFC.Model.NBFC;

public interface NBFCRepo extends JpaRepository<NBFC,Integer>
{

}
