package com.project.NBFC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NbfcApplication {

	public static void main(String[] args) {
		SpringApplication.run(NbfcApplication.class, args);
	}

}
